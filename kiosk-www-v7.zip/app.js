/* Customer self-order kiosk — Phase 1 (ordering; payment is Phase 2, Stripe Terminal).
 * Talks only to the PUBLIC backend endpoints, so this device holds no staff credential:
 *   GET  /public/menu/:restaurantId   → restaurant + items
 *   POST /public/order                → places the order, server prices it
 */
const KIOSK_VERSION = 7;
const DEFAULT_BACKEND = 'https://restaurant-orders-backend-v1-production.up.railway.app';
const K_URL = 'kiosk_backend', K_RID = 'kiosk_restaurant_id', K_IMG = 'kiosk_image_base';
// Dish photos: filenames are slugs of the dish name (e.g. "Kutchi Dabeli" -> kutchi-dabeli.jpg).
// Built-in bases for known restaurants; overridable per device in setup. Missing photos fall back
// to a tasteful tile, so this is safe even when a dish has no image.
const KNOWN_IMAGE_BASES = { 6: 'https://www.aamchimumbai.us/img/' };

const $ = id => document.getElementById(id);
const money = v => '$' + (Number(v) || 0).toFixed(2);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

let CFG = { url: '', rid: 0 };
let MENU = null;           // { restaurant, open, items, cats }
let orderType = 'pickup';  // 'pickup' | 'dinein'
let cart = [];             // [{ key, name, size, unit, qty, opts:[], note }]
let activeCat = null;
let viewMode = localStorage.getItem('kiosk_view') || 'compact';   // 'compact' | 'photos'

function getCfg() {
  const rid = Number(localStorage.getItem(K_RID) || 0);
  const imgBase = (localStorage.getItem(K_IMG) || KNOWN_IMAGE_BASES[rid] || '').replace(/\/?$/, m => m || '');
  return { url: (localStorage.getItem(K_URL) || DEFAULT_BACKEND).replace(/\/$/, ''), rid,
           imgBase: imgBase ? imgBase.replace(/\/*$/, '/') : '' };
}
const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
function imgBase(name) { return CFG.imgBase ? CFG.imgBase + slug(name) : ''; }
// An <img> that tries .jpg, then .png, then .webp before giving up — dishes are photographed
// in different formats/qualities, so trying several finds the best available.
function imgTag(name) {
  const b = imgBase(name);
  return b ? `<img src="${esc(b)}.jpg" data-b="${esc(b)}" data-i="0" alt="" onerror="imgNext(this)">` : '';
}
window.imgNext = function (img) {
  // .png before .webp: some dishes only ship a tiny, over-compressed .webp but a full-quality
  // .png (e.g. Kutchi Dabeli), so prefer the .png when there's no .jpg.
  const ext = ['jpg', 'png', 'webp'];
  const i = (+img.dataset.i || 0) + 1;
  if (i < ext.length) { img.dataset.i = i; img.src = img.dataset.b + '.' + ext[i]; }
  else { const hero = img.closest('.sheet-hero'); img.remove(); if (hero) hero.remove(); }
};
function show(id) { document.querySelectorAll('.screen').forEach(s => s.classList.remove('on')); $(id).classList.add('on'); }
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('on'), 2600); }

// ── Setup ──
function saveSetup() {
  const rid = Number($('cfg-rid').value.trim());
  const url = $('cfg-url').value.trim().replace(/\/$/, '') || DEFAULT_BACKEND;
  const img = ($('cfg-img') ? $('cfg-img').value.trim() : '');
  if (!rid) { $('setup-err').textContent = 'Enter the restaurant ID.'; return; }
  localStorage.setItem(K_RID, String(rid));
  localStorage.setItem(K_URL, url);
  if (img) localStorage.setItem(K_IMG, img); else localStorage.removeItem(K_IMG);
  CFG = getCfg();
  boot();
}

// ── Load menu ──
async function loadMenu() {
  const r = await fetch(`${CFG.url}/public/menu/${CFG.rid}`, { cache: 'no-store' });
  if (!r.ok) throw new Error('menu ' + r.status);
  const d = await r.json();
  if (!d.ok) throw new Error(d.error || 'menu');
  // Group items by category, preserving server order.
  const cats = [];
  const byCat = {};
  (d.items || []).forEach(it => {
    const c = it.category || 'Menu';
    if (!byCat[c]) { byCat[c] = []; cats.push(c); }
    byCat[c].push(it);
  });
  MENU = { restaurant: d.restaurant || { name: 'Restaurant' }, open: d.open, closedReason: d.closedReason, byCat, cats };
  return MENU;
}

// ── Attract ──
function initial(s) { const c = (String(s || '').trim()[0] || '🍽️'); return c === '🍽️' ? c : c.toUpperCase(); }
// Restaurant logo (img/logo-180.png on the image host) with the letter as a fallback.
function brandLogo(nm) {
  return CFG.imgBase
    ? `${initial(nm)}<img class="brand-img" src="${esc(CFG.imgBase)}logo-180.png" alt="" onerror="this.remove()">`
    : initial(nm);
}
function renderAttract() {
  const nm = MENU.restaurant.name || 'Restaurant';
  $('a-name').textContent = nm;
  $('a-sub').textContent = MENU.restaurant.location || '';
  $('a-logo').innerHTML = brandLogo(nm);
  const closed = $('a-closed');
  if (MENU.open === false) { closed.hidden = false; closed.textContent = '⏳ ' + (MENU.closedReason || 'Currently closed'); }
  else closed.hidden = true;
}

function startOrder() {
  if (MENU.open === false) { toast('Sorry — we’re closed right now.'); return; }
  cart = [];
  show('ordertype');
}
function chooseType(t) { orderType = t; renderMenu(); show('menu'); }

// ── Menu render ──
const ALL = 'All';
// Category icon = the first item in that category that has a photo (falls back to an emoji).
function catIcon(cat) {
  const it = (MENU.byCat[cat] || []).find(x => imgBase(x.name));
  return it ? imgTag(it.name) : "🍽️";
}
function renderMenu() {
  const nm = MENU.restaurant.name || 'Menu';
  $('k-logo').innerHTML = brandLogo(nm);
  $('m-mode').textContent = orderType === 'dinein' ? '🍽️ Dine-in' : '🥡 Pickup';
  const tabs = [ALL, ...MENU.cats];
  activeCat = activeCat && tabs.includes(activeCat) ? activeCat : ALL;
  $('cat-title').textContent = activeCat === ALL ? 'Full menu' : activeCat;
  $('knav').innerHTML = tabs.map(c => {
    const ic = c === ALL ? '🍴' : catIcon(c);
    return `<button class="kcat ${c === activeCat ? 'on' : ''}" onclick="selectCat('${esc(c).replace(/'/g, "\\'")}')">
      <span class="kcat-ic">${ic}</span><span class="kcat-nm">${esc(c)}</span></button>`;
  }).join('');
  renderItems();
  renderCartBar();
}
function selectCat(c) { activeCat = c; renderMenu(); $('items').scrollTop = 0; }

// Photo card, Toast-style: image, name, price. Tapping opens the options sheet.
function itemCard(cat, it, i) {
  const out = it.available === false;
  const label = it.name + (it.size ? ` (${it.size})` : '');
  const img = `<div class="pcard-img"><span class="ph">🍽️</span>${imgTag(it.name)}</div>`;
  return `<button class="pcard ${out ? 'out' : ''}" ${out ? 'disabled' : ''}
      onclick="openItem('${esc(cat).replace(/'/g, "\\'")}',${i})">
    ${img}
    <div class="pcard-nm">${esc(label)}</div>
    <div class="pcard-price">${money(it.price)}</div>
  </button>`;
}

function renderItems() {
  const box = $('items');
  if (activeCat === ALL) {
    box.innerHTML = MENU.cats.map(cat => {
      const cards = (MENU.byCat[cat] || []).map((it, i) => itemCard(cat, it, i)).join('');
      return `<section class="cat-section"><h3 class="cat-h">${esc(cat)}</h3><div class="pgrid">${cards}</div></section>`;
    }).join('');
  } else {
    const items = MENU.byCat[activeCat] || [];
    box.innerHTML = items.length
      ? `<div class="pgrid">${items.map((it, i) => itemCard(activeCat, it, i)).join('')}</div>`
      : `<div style="color:var(--muted);padding:40px">No items in ${esc(activeCat)}.</div>`;
  }
}

// ── Item customize sheet ──
let draft = null;
function openItem(cat, idx) {
  const it = MENU.byCat[cat][idx];
  draft = { name: it.name, size: it.size || '', unit: Number(it.price), qty: 1, spice: null, note: '' };
  const spiceScale = Number(MENU.restaurant.spiceScale) || 0;
  const spiceOpts = spiceScale >= 3 ? ['Mild', 'Medium', 'Hot'] : [];
  const label = it.name + (it.size ? ` (${it.size})` : '');
  const t = imgTag(it.name);
  const hero = t ? `<div class="sheet-hero">${t}</div>` : "";
  $('sheet').innerHTML = `
    <div class="sheet-h"><h3>${esc(label)}</h3><button class="x" onclick="closeModal()">✕</button></div>
    <div class="sheet-b">
      ${hero}
      ${it.description ? `<p style="color:var(--muted);margin:0 0 6px">${esc(it.description)}</p>` : ''}
      ${spiceOpts.length ? `<div class="grp-label">Spice level</div>
        <div class="choices" id="d-spice">${spiceOpts.map(s => `<button class="choice" onclick="pickSpice(this,'${s}')">${s}</button>`).join('')}</div>` : ''}
      <div class="grp-label">Special requests (optional)</div>
      <input class="note-in" id="d-note" placeholder="e.g. no onions, extra sauce" maxlength="120">
      <div class="grp-label">Quantity</div>
      <div class="qty"><button onclick="bumpQty(-1)">−</button><span class="n" id="d-qty">1</span><button onclick="bumpQty(1)">+</button></div>
    </div>
    <div class="sheet-f">
      <button class="ghost" onclick="closeModal()">Cancel</button>
      <button class="primary block" id="d-add" onclick="addDraft()">Add ${money(it.price)}</button>
    </div>`;
  openModal();
}
function pickSpice(el, s) { draft.spice = draft.spice === s ? null : s;
  el.parentElement.querySelectorAll('.choice').forEach(c => c.classList.toggle('on', c === el && draft.spice === s)); }
function bumpQty(d) { draft.qty = Math.max(1, draft.qty + d); $('d-qty').textContent = draft.qty;
  $('d-add').textContent = `Add ${money(draft.unit * draft.qty)}`; }
function addDraft() {
  draft.note = $('d-note').value.trim();
  const opts = [];
  if (draft.spice) opts.push(draft.spice);
  if (draft.note) opts.push(draft.note);
  cart.push({ name: draft.name, size: draft.size, unit: draft.unit, qty: draft.qty, opts,
              note: opts.join('; ') });
  closeModal(); renderCartBar();
  toast('Added to order');
}

// ── Cart ──
function cartCount() { return cart.reduce((n, l) => n + l.qty, 0); }
function cartSubtotal() { return cart.reduce((s, l) => s + l.unit * l.qty, 0); }
function renderCartBar() {
  $('orderbar').classList.toggle('show', cartCount() > 0);
  $('ob-total').textContent = money(cartSubtotal());
}
function openCart() {
  if (!cart.length) return;
  const lines = cart.map((l, i) => `
    <div class="cline">
      <span class="cq">${l.qty}×</span>
      <div class="cbody"><div class="cnm">${esc(l.name)}${l.size ? ' (' + esc(l.size) + ')' : ''}</div>
        ${l.opts.length ? `<div class="copt">${esc(l.opts.join(' · '))}</div>` : ''}
        <button class="crm" onclick="removeLine(${i})">Remove</button></div>
      <span class="cp">${money(l.unit * l.qty)}</span>
    </div>`).join('');
  $('sheet').innerHTML = `
    <div class="sheet-h"><h3>Your order</h3><button class="x" onclick="closeModal()">✕</button></div>
    <div class="sheet-b">
      ${lines}
      <div class="tot"><span>Subtotal</span><span>${money(cartSubtotal())}</span></div>
      <div class="tot" style="font-size:14px"><span>Tax</span><span>calculated at checkout</span></div>
    </div>
    <div class="sheet-f">
      <button class="ghost" onclick="closeModal()">Add more</button>
      <button class="primary block" onclick="openDetails()">Checkout · ${money(cartSubtotal())}</button>
    </div>`;
  openModal();
}
function removeLine(i) { cart.splice(i, 1); renderCartBar(); if (cart.length) openCart(); else closeModal(); }

// ── Details (name / phone / table) ──
function openDetails() {
  $('sheet').innerHTML = `
    <div class="sheet-h"><h3>Almost done</h3><button class="x" onclick="closeModal()">✕</button></div>
    <div class="sheet-b">
      <div class="field"><label>Name for the order</label><input id="o-name" autocomplete="off" maxlength="40"></div>
      <div class="field"><label>Mobile number (for order updates)</label>
        <input id="o-phone" inputmode="numeric" autocomplete="off" placeholder="10-digit number" maxlength="14"></div>
      ${orderType === 'dinein' ? `<div class="field"><label>Table number</label>
        <input id="o-table" inputmode="numeric" autocomplete="off" maxlength="6"></div>` : ''}
      <div id="o-err" style="color:#f0908c;min-height:20px;margin-top:12px"></div>
    </div>
    <div class="sheet-f">
      <button class="ghost" onclick="openCart()">‹ Back</button>
      <button class="primary block" id="o-place" onclick="placeOrder()">Place order</button>
    </div>`;
  openModal();
  setTimeout(() => $('o-name').focus(), 150);
}

async function placeOrder() {
  const name = $('o-name').value.trim();
  const phone = $('o-phone').value.replace(/\D/g, '');
  const table = orderType === 'dinein' ? ($('o-table')?.value.trim() || '') : '';
  const err = $('o-err');
  if (!name) { err.textContent = 'Please enter a name.'; return; }
  if (phone.length !== 10) { err.textContent = 'Please enter a 10-digit mobile number.'; return; }
  if (orderType === 'dinein' && !table) { err.textContent = 'Please enter your table number.'; return; }

  const btn = $('o-place'); btn.disabled = true; btn.textContent = 'Placing…';
  // Per-item note carries the customizations; the order-level note carries the fulfilment type.
  const items = cart.map(l => ({ name: l.name + (l.size ? ` (${l.size})` : ''), qty: l.qty, note: l.note || '' }));
  const orderNote = orderType === 'dinein' ? `Dine-in — Table ${table}` : 'Pickup';
  try {
    const r = await fetch(`${CFG.url}/public/order`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ restaurantId: CFG.rid, items, name, phone, note: orderNote }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) {
      const map = { closed: 'Sorry, we just closed.', name_required: 'Please enter a name.',
        phone_invalid: 'That phone number looks wrong.', no_items: 'Your order is empty.',
        rate_limited: 'Too many orders from this device — try again shortly.' };
      err.textContent = map[d.error] || 'Could not place the order. Please try again.';
      btn.disabled = false; btn.textContent = 'Place order'; return;
    }
    // Phase 2 inserts Stripe Terminal payment here, before showing confirmation.
    closeModal();
    $('d-num').textContent = 'Order #' + (String(d.orderId).slice(-5));
    $('d-sub').textContent = `${name}, your total is ${money(d.total)}. ` +
      (orderType === 'dinein' ? `We’ll bring it to table ${table}.` : `We’ll call your name at the counter.`);
    show('done');
  } catch (_) {
    err.textContent = 'Network problem. Please try again.';
    btn.disabled = false; btn.textContent = 'Place order';
  }
}

function resetToAttract() {
  cart = []; orderType = 'pickup'; activeCat = null;
  loadMenu().then(renderAttract).catch(() => {});
  show('attract');
  checkUpdate(false);        // returning to idle is a good moment to look for updates
  applyPendingIfIdle();      // and to apply one already downloaded, between customers
}

// ── Modal helpers ──
function openModal() { $('modal').classList.add('on'); }
function closeModal() { $('modal').classList.remove('on'); }
$('modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });

// ── OTA web updates (silent; applied between customers, never mid-order) ──
const WEB_UPDATE_MANIFEST = 'https://raw.githubusercontent.com/jgreenrise/orders-ota-/main/kiosk-app-version.json';
const WEB_UPDATE_INTERVAL_MS = 60 * 60 * 1000;
let lastUpdCheck = 0, pendingUpdate = false;
function wu() {
  return (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()
    && Capacitor.Plugins && Capacitor.Plugins.WebUpdate) || null;
}
async function markHealthy() { const p = wu(); try { if (p) await p.markHealthy(); } catch (_) {} }
async function checkUpdate(force) {
  const p = wu(); if (!p) return;
  const now = Date.now();
  if (!force && now - lastUpdCheck < WEB_UPDATE_INTERVAL_MS) return;
  lastUpdCheck = now;
  try {
    const nativeV = (await p.getInfo())?.nativeVersion || 1;
    const r = await fetch(`${WEB_UPDATE_MANIFEST}?t=${now}`, { cache: 'no-store' });
    if (!r.ok) return;
    const m = await r.json();
    if (m && m.url && m.version > KIOSK_VERSION && (m.minNative || 0) <= nativeV) {
      const staged = await p.applyUpdate({ url: m.url, version: m.version });   // download in background
      if (staged && staged.ok) { pendingUpdate = true; if (m.force) await p.applyNow(); }
    }
  } catch (_) {}
}
// The attract screen is the only truly idle moment — apply a staged update there so a reload
// never interrupts a customer mid-order.
async function applyPendingIfIdle() { if (pendingUpdate) { const p = wu(); try { if (p) await p.applyNow(); } catch (_) {} } }

// ── Boot ──
async function boot() {
  $('kioskver').textContent = 'kiosk v' + KIOSK_VERSION;
  CFG = getCfg();
  if (!CFG.rid) {
    $('cfg-url').value = CFG.url;
    show('setup'); return;
  }
  try {
    await loadMenu();
    renderAttract();
    show('attract');
    markHealthy();
    checkUpdate(true);
    setInterval(() => checkUpdate(false), 15 * 60 * 1000);   // hourly-gated; fires between customers
  } catch (e) {
    $('setup-err').textContent = 'Could not load the menu for restaurant ' + CFG.rid + '. Check the ID and connection.';
    $('cfg-rid').value = CFG.rid; $('cfg-url').value = CFG.url;
    show('setup');
  }
}
window.addEventListener('load', boot);
