/* Native bridge — the single seam between the web portal and device hardware.
 *
 * The portal is hardware-blind: it calls window.CounterNative.alert(), and THIS file decides
 * how that happens on the device it is running on. In a plain browser CounterNative is still
 * defined but its methods no-op or fall back to Web Audio, so the exact same portal code runs
 * in Chrome, as a PWA, and inside the app.
 */
(function () {
  const isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  // ── new-order alert sound: Web Audio works in browser AND inside the webview ──
  let audioCtx = null;
  function beep() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      // Two rising tones — distinct from a notification, hard to miss on a busy counter.
      [ [880, 0], [1320, 0.18] ].forEach(([f, t]) => {
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.frequency.value = f; o.type = 'square';
        g.gain.setValueAtTime(0.0001, audioCtx.currentTime + t);
        g.gain.exponentialRampToValueAtTime(0.3, audioCtx.currentTime + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + t + 0.16);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(audioCtx.currentTime + t); o.stop(audioCtx.currentTime + t + 0.17);
      });
    } catch (_) {}
  }

  // The OrdersNative plugin (Android) owns everything that must outlive the webview: the
  // background order watcher, its credentials, and system notifications. Guarded so the same
  // UI code runs unchanged in a plain browser and on iOS, where the plugin does not exist yet.
  function ordersPlugin() {
    return (isNative && window.Capacitor.Plugins && window.Capacitor.Plugins.OrdersNative) || null;
  }
  function webUpdatePlugin() {
    return (isNative && window.Capacitor.Plugins && window.Capacitor.Plugins.WebUpdate) || null;
  }

  window.CounterNative = {
    isNative,
    // Sound + a phone buzz on native. Called by the portal when a new order is detected.
    async alert() {
      beep();
      try { if (isNative && window.Capacitor.Plugins.Haptics)
        await window.Capacitor.Plugins.Haptics.vibrate({ duration: 400 }); } catch (_) {}
    },
    // Hand the session token to the native background service (and revoke it on sign-out).
    // Without creds the service stays silent, so sign-out really does stop the alerts.
    async syncCreds(token, baseUrl) {
      const p = ordersPlugin();
      try { if (p) await p.syncCreds({ token: token || '', baseUrl: baseUrl || '' }); } catch (_) {}
    },
    async clearCreds() {
      const p = ordersPlugin();
      try { if (p) await p.clearCreds(); } catch (_) {}
    },
    // Post a real system notification for a new order. De-duplicated natively by order id
    // against the background service, so UI and service can both call this freely.
    async notifyNewOrder(orderId, title, body) {
      const p = ordersPlugin();
      try { if (p) await p.notifyNewOrder({ orderId: String(orderId || ''), title, body }); } catch (_) {}
    },
    // Counter tablets should not dim mid-service; the UI exposes this as a toggle.
    async setKeepAwake(on) {
      const p = ordersPlugin();
      try { if (p) await p.setKeepAwake({ on: !!on }); } catch (_) {}
    },

    // ── Over-the-air web updates (Android). Guarded so the browser/iOS just report the bundled
    //    version and no-op the rest. See WebUpdatePlugin for the download/stage/rollback logic. ──
    async webUpdateInfo() {
      const p = webUpdatePlugin();
      try { if (p) return await p.getInfo(); } catch (_) {}
      return { webVersion: 1, nativeVersion: 1 };   // bundled defaults off-Android
    },
    async webUpdateApply(url, version) {
      const p = webUpdatePlugin();
      try { if (p) return await p.applyUpdate({ url, version }); } catch (e) { return { ok: false, message: String(e) }; }
      return { ok: false, message: 'not-native' };
    },
    async webUpdateHealthy() {
      const p = webUpdatePlugin();
      try { if (p) await p.markHealthy(); } catch (_) {}
    },
    // Mandatory update: apply the staged bundle immediately (reloads the WebView) instead of
    // waiting for the next launch.
    async webUpdateApplyNow() {
      const p = webUpdatePlugin();
      try { if (p) return await p.applyNow(); } catch (_) {}
      return { ok: false };
    },
    // Create/resume the audio context inside a user gesture WITHOUT playing anything, so the
    // first real alert beep is not swallowed by autoplay policy.
    armAudio() {
      try {
        audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
      } catch (_) {}
    },
    _beep: beep,   // exposed for testing
  };
})();
