/* Customer self-order kiosk — Phase 1 (ordering; payment is Phase 2, Stripe Terminal).
 * Talks only to the PUBLIC backend endpoints, so this device holds no staff credential:
 *   GET  /public/menu/:restaurantId   → restaurant + items
 *   POST /public/order                → places the order, server prices it
 */
const KIOSK_VERSION = 19;
const DEFAULT_BACKEND = 'https://restaurant-orders-backend-v1-production.up.railway.app';
const DEFAULT_ADMIN = 'https://admin-portal-production-1259.up.railway.app';   // staff web portal
const K_URL = 'kiosk_backend', K_RID = 'kiosk_restaurant_id', K_IMG = 'kiosk_image_base', K_PIN = 'kiosk_staff_pin', K_ADMIN = 'kiosk_admin_url';
// No shared default PIN — each restaurant's kiosk gets its own, set once at setup and kept
// on this device. Without a PIN the staff gate can't be opened.
// Dish photos: filenames are slugs of the dish name (e.g. "Kutchi Dabeli" -> kutchi-dabeli.jpg).
// Built-in bases for known restaurants; overridable per device in setup. Missing photos fall back
// to a tasteful tile, so this is safe even when a dish has no image.
const KNOWN_IMAGE_BASES = { 6: 'https://www.aamchimumbai.us/img/' };

const $ = id => document.getElementById(id);
const money = v => '$' + (Number(v) || 0).toFixed(2);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

let CFG = { url: '', rid: 0 };
let MENU = null;           // { restaurant, open, items, cats }
let orderType = 'pickup';  // 'pickup' | 'dinein'
let cart = [];             // [{ key, name, size, unit, qty, opts:[], note }]
let activeCat = null;
let viewMode = localStorage.getItem('kiosk_view') || 'compact';   // 'compact' | 'photos'
let superAdmin = false;        // session-only: unlocked by the super-admin PIN; lets staff change restaurant
let staffPurpose = 'home';     // what the staff-gate PIN prompt is for: 'home' | 'superadmin'

function getCfg() {
  const rid = Number(localStorage.getItem(K_RID) || 0);
  const imgBase = (localStorage.getItem(K_IMG) || KNOWN_IMAGE_BASES[rid] || '').replace(/\/?$/, m => m || '');
  return { url: (localStorage.getItem(K_URL) || DEFAULT_BACKEND).replace(/\/$/, ''), rid,
           imgBase: imgBase ? imgBase.replace(/\/*$/, '/') : '',
           pin: (localStorage.getItem(K_PIN) || ''),
           adminUrl: (localStorage.getItem(K_ADMIN) || DEFAULT_ADMIN).replace(/\/$/, '') };
}
const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
function imgBase(name) { return CFG.imgBase ? CFG.imgBase + slug(name) : ''; }
// An <img> that tries .jpg, then .png, then .webp before giving up — dishes are photographed
// in different formats/qualities, so trying several finds the best available.
const SMALL_WORDS = new Set(['and','with','in','of','the','a','on','or','&']);
function titleCase(str) {
  return String(str).split(' ').map((w, i) =>
    (i && SMALL_WORDS.has(w.toLowerCase())) ? w.toLowerCase()
      : w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function imgTag(name) {
  const b = imgBase(name);
  return b ? `<img src="${esc(b)}.jpg" data-b="${esc(b)}" data-i="0" alt="" onerror="imgNext(this)">` : '';
}
window.imgNext = function (img) {
  // .png before .webp: some dishes only ship a tiny, over-compressed .webp but a full-quality
  // .png (e.g. Kutchi Dabeli), so prefer the .png when there's no .jpg.
  const ext = ['jpg', 'png', 'webp'];
  const i = (+img.dataset.i || 0) + 1;
  if (i < ext.length) { img.dataset.i = i; img.src = img.dataset.b + '.' + ext[i]; }
  else { const hero = img.closest('.sheet-hero'); img.remove(); if (hero) hero.remove(); }
};
function show(id) { document.querySelectorAll('.screen').forEach(s => s.classList.remove('on')); $(id).classList.add('on'); }
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('on'), 2600); }

// ── Setup ──
function saveSetup() {
  // The restaurant is chosen once, at first provisioning, then locked: a kiosk can't be
  // switched to another restaurant from Settings, so restaurant A can't turn its device into
  // restaurant B's. Re-provisioning means a reinstall/reset.
  // Setup asks only two things: the restaurant and the staff PIN. Backend URL, dish-image base
  // and admin-portal URL all use built-in defaults (per-restaurant image base by ID).
  const existingRid = Number(localStorage.getItem(K_RID) || 0);
  // The restaurant is locked to normal staff; only first-run or a super-admin may set/change it.
  const rid = (superAdmin || !existingRid) ? Number($('cfg-rid').value.trim()) : existingRid;
  const pin = ($('cfg-pin') ? $('cfg-pin').value.trim() : '');
  const existingPin = localStorage.getItem(K_PIN) || '';
  if (!rid) { $('setup-err').textContent = 'Enter the restaurant ID.'; return; }
  // A staff PIN is what guards Settings and exit — required, with no shared default. Digits only.
  if (!pin && !existingPin) { $('setup-err').textContent = 'Set a staff exit PIN.'; return; }
  if (pin && !/^\d{4,8}$/.test(pin)) { $('setup-err').textContent = 'PIN must be 4–8 digits.'; return; }
  localStorage.setItem(K_RID, String(rid));
  if (pin) localStorage.setItem(K_PIN, pin);   // blank leaves the existing PIN untouched
  superAdmin = false;   // leaving settings drops super-admin
  CFG = getCfg();
  boot();
}
// Render the Settings/setup screen for the current mode: first-run shows an editable Restaurant ID;
// provisioned staff see the restaurant NAME (locked) plus Upgrade + Super-admin; super-admin (or a
// failed menu load) re-exposes the editable Restaurant ID so it can be changed/corrected.
function renderSetup() {
  const provisioned = !!localStorage.getItem(K_RID);
  const c = getCfg();
  const haveName = !!(MENU && MENU.restaurant && MENU.restaurant.name);
  const showRid = !provisioned || superAdmin || !haveName;
  $('cfg-rid-row').hidden = !showRid;
  $('cfg-rname-row').hidden = showRid;
  if (showRid) $('cfg-rid').value = (superAdmin || !haveName) ? (c.rid || '') : '';
  else $('cfg-rname').textContent = MENU.restaurant.name;
  $('cfg-pin').value = '';
  $('cfg-pin').placeholder = provisioned ? 'leave blank to keep current PIN' : 'set a PIN for this restaurant';
  $('setup-title').textContent = provisioned ? 'Settings' : 'Kiosk setup';
  $('setup-desc').hidden = provisioned;
  $('setup-actions').hidden = !provisioned;
  $('sa-btn').hidden = superAdmin;
  $('sa-badge').hidden = !superAdmin;
  $('setup-status').textContent = '';
}

// ── Staff gate ──────────────────────────────────────────────────────────────
// Customers never see this. Staff reveal it with a 3-finger tap (or 5 quick taps
// on the "kiosk vN" tag, handy on a simulator with no multi-touch), enter the PIN,
// then reach Settings or exit the app.
function openStaff(purpose) {
  staffPurpose = (purpose === 'superadmin') ? 'superadmin' : 'home';
  const sa = staffPurpose === 'superadmin';
  if ($('sg-title')) $('sg-title').textContent = sa ? 'Super admin' : 'Staff access';
  if ($('sg-desc')) $('sg-desc').textContent = sa ? 'Enter the super-admin PIN.' : 'Enter the staff PIN.';
  $('sg-pin').value = '';
  $('sg-err').textContent = '';
  $('staffgate').hidden = false;
  setTimeout(() => { try { $('sg-pin').focus(); } catch (_) {} }, 50);
}
function closeStaff() { $('staffgate').hidden = true; }
// After the PIN: the staff "home" screen — the hub staff land on when they leave the customer
// kiosk. From here they can upgrade the app, open the admin portal, change settings, resume the
// kiosk, or exit to the device.
function openStaffMenu() {
  closeStaff();
  $('sh-name').textContent = (MENU && MENU.restaurant && MENU.restaurant.name) || 'Kiosk';
  $('sh-ver').textContent = 'v' + KIOSK_VERSION;
  $('sh-status').textContent = '';
  show('staffhome');
}
function resumeKiosk() { resetToAttract(); }
// Upgrade: on a native tablet, force an OTA check and apply any newer bundle; on the browser
// kiosk (Mac) there's no OTA plugin, so just reload the latest from the server.
async function upgradeApp(statusId) {
  const st = $(statusId || 'sh-status');
  const p = wu();
  if (!p) { st.textContent = 'Reloading…'; setTimeout(() => location.reload(), 400); return; }
  st.textContent = 'Checking for updates…';
  lastUpdCheck = 0; pendingUpdate = false;
  await checkUpdate(true);
  if (pendingUpdate) {
    st.textContent = 'Update found — applying…';
    try { await p.applyNow(); } catch (_) { st.textContent = 'Update failed — try again.'; }
  } else {
    st.textContent = 'You’re on the latest version (v' + KIOSK_VERSION + ').';
  }
}
// Open the staff web portal. On a native tablet this hands off to the system browser; in the
// browser kiosk it opens a new tab — either way the kiosk itself stays put.
function openAdminPortal() {
  const url = getCfg().adminUrl;
  if (!url) { toast('No admin portal URL set.'); return; }
  try { window.open(url, '_system'); } catch (_) { try { window.open(url, '_blank'); } catch (e) {} }
}
// Leave the app entirely (native): close to the launcher. iOS/Mac have no programmatic exit.
function exitToDevice() {
  const cap = window.Capacitor && window.Capacitor.Plugins;
  if (cap && cap.WebUpdate && typeof cap.WebUpdate.exitApp === 'function') { try { cap.WebUpdate.exitApp(); return; } catch (_) {} }
  toast('On this device, close the app from the tablet’s launcher.');
}
// Three ways to unlock: this device's own PIN (checked locally, works offline), or — verified
// by the backend so the codes never live on the device — the restaurant master PIN or the global
// superadmin PIN. A forgotten device PIN is no longer a lockout: a master unlocks any kiosk.
async function staffUnlock() {
  const entered = ($('sg-pin').value || '').trim();
  if (!entered) { $('sg-err').textContent = 'Wrong PIN.'; return; }
  const superOnly = (staffPurpose === 'superadmin');   // super-admin mode needs the superadmin PIN
  // 1) Device PIN — local, instant, offline. Unlocks the staff home only, never super admin.
  if (!superOnly && entered === String(getCfg().pin)) { openStaffMenu(); return; }
  // 2) Restaurant / superadmin master — verified server-side (nothing secret ships to the device).
  if (/^\d{4,8}$/.test(entered)) {
    $('sg-err').textContent = 'Checking…';
    try {
      const r = await fetch(`${CFG.url}/public/kiosk/unlock`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ restaurantId: CFG.rid, pin: entered }),
      });
      const d = await r.json().catch(() => ({}));
      if (r.status === 429) { $('sg-err').textContent = 'Too many tries — wait a few minutes.'; $('sg-pin').value = ''; return; }
      if (d && d.ok) {
        if (superOnly) {
          if (d.level === 'superadmin') { enterSuperAdmin(); return; }
          $('sg-err').textContent = 'That’s not the super-admin PIN.'; $('sg-pin').value = ''; return;
        }
        openStaffMenu(); return;
      }
    } catch (_) { $('sg-err').textContent = 'Network problem — try again.'; return; }
  }
  $('sg-err').textContent = 'Wrong PIN.';
  $('sg-pin').value = '';
}
function openSuperAdmin() { openStaff('superadmin'); }
function enterSuperAdmin() {
  closeStaff();
  superAdmin = true;   // restaurant becomes editable until they leave Settings
  $('setup-err').textContent = '';
  renderSetup();
  show('setup');
}
function staffSettings() {
  closeStaff();
  superAdmin = false;
  $('setup-err').textContent = '';
  renderSetup();
  show('setup');
}
// Gesture + fallback wiring. Three ways in, so it works on real hardware, a
// simulator, and with a mouse — all hidden from customers:
//   • 3-finger tap anywhere (touch hardware)
//   • press-and-hold the logo ~1.2s (works with a mouse / on a simulator)
//   • 5 quick taps on the version tag (secondary)
function wireStaffGate() {
  document.addEventListener('touchstart', e => {
    if (e.touches && e.touches.length === 3 && $('staffgate').hidden) openStaff();
  }, { passive: true });
  ['a-logo', 'k-logo'].forEach(id => {
    const el = $(id); if (!el) return;
    let t = 0;
    const start = () => { clearTimeout(t); t = setTimeout(() => { if ($('staffgate').hidden) openStaff(); }, 1200); };
    const cancel = () => clearTimeout(t);
    el.addEventListener('pointerdown', start);
    el.addEventListener('pointerup', cancel);
    el.addEventListener('pointerleave', cancel);
    el.addEventListener('pointercancel', cancel);
  });
  let taps = 0, tt = 0;
  const ver = $('kioskver');
  if (ver) ver.addEventListener('click', () => {
    clearTimeout(tt); taps++; tt = setTimeout(() => taps = 0, 1200);
    if (taps >= 5) { taps = 0; openStaff(); }
  });
}
// ── Drag to scroll ──────────────────────────────────────────────────────────
// macOS has no native touchscreen support, so a finger on the panel arrives as a
// mouse drag — and a mouse drag is a text selection, not a scroll. Nothing in CSS
// can fix that; the page has to turn the drag into a scroll itself.
//
// Delegated from document rather than bound per element: the dish sheet's body is
// rebuilt each time an item opens, so anything bound directly would be attached to
// a node that no longer exists.
function wireDragScroll() {
  const SCROLLERS = '.kcontent,.krail,.sheet-b';
  const THRESHOLD = 8;          // px before a press becomes a scroll rather than a tap
  const FRICTION  = 0.94;       // per frame; lower stops sooner, higher glides further
  const MIN_V     = 0.02;       // px/ms — below this the glide is invisible, so stop

  let el = null, startY = 0, startTop = 0, moved = false, justDragged = false;
  let targetTop = 0, raf = 0;                    // drag write, batched to the frame
  let lastY = 0, lastT = 0, velocity = 0;        // px/ms, for the throw
  let glide = 0, glideEl = null;

  const clamp = (node, v) => Math.max(0, Math.min(v, node.scrollHeight - node.clientHeight));

  // Writing scrollTop on every pointermove paints out of step with the display and reads as
  // stutter. One write per frame instead, which is all the screen can show anyway.
  function flush() {
    raf = 0;
    if (el) el.scrollTop = targetTop;
  }
  function stopGlide() {
    if (glide) { cancelAnimationFrame(glide); glide = 0; }
    glideEl = null;
  }
  // A real touch scroll keeps moving after the finger lifts. Without this the list stops dead
  // on release, which is the single thing that makes a drag feel mechanical rather than smooth.
  function startGlide(node, v) {
    stopGlide();
    glideEl = node;
    let vel = v, last = performance.now();
    const step = now => {
      const dt = Math.min(now - last, 32); last = now;
      vel *= Math.pow(FRICTION, dt / 16.7);
      const next = clamp(node, node.scrollTop - vel * dt);
      if (Math.abs(vel) < MIN_V || next === node.scrollTop) { stopGlide(); return; }
      node.scrollTop = next;
      glide = requestAnimationFrame(step);
    };
    glide = requestAnimationFrame(step);
  }

  document.addEventListener('pointerdown', e => {
    // Real touch hardware scrolls natively — driving it again here would double every swipe.
    if (e.pointerType === 'touch' || e.button !== 0) return;
    if (e.target.closest('input,textarea,select')) return;   // let fields take their own presses
    stopGlide();                                             // a new press catches the list
    el = e.target.closest(SCROLLERS);
    if (!el) return;
    startY = e.clientY; startTop = el.scrollTop; targetTop = startTop; moved = false;
    lastY = e.clientY; lastT = performance.now(); velocity = 0;
  });

  document.addEventListener('pointermove', e => {
    if (!el) return;
    const dy = e.clientY - startY;
    if (!moved) {
      if (Math.abs(dy) < THRESHOLD) return;
      // Past the threshold this is a scroll. Capture the pointer so it keeps scrolling when the
      // finger leaves the card it started on — the grid is wall-to-wall buttons.
      moved = true;
      try { el.setPointerCapture(e.pointerId); } catch (_) {}
    }
    const now = performance.now(), dt = now - lastT;
    // Smoothed so one stuttery sample cannot throw the list across the menu on release.
    if (dt > 0) velocity = velocity * 0.7 + ((e.clientY - lastY) / dt) * 0.3;
    lastY = e.clientY; lastT = now;

    targetTop = clamp(el, startTop - dy);
    if (!raf) raf = requestAnimationFrame(flush);
    e.preventDefault();
  });

  const end = e => {
    if (!el) return;
    try { el.releasePointerCapture(e.pointerId); } catch (_) {}
    if (raf) { cancelAnimationFrame(raf); flush(); }
    if (moved) {
      // A pause before releasing means the customer meant to stop there, not to throw the list.
      if (performance.now() - lastT < 90 && Math.abs(velocity) > MIN_V) startGlide(el, velocity);
      // pointerup is followed by a click on whatever the drag began over. Swallow that one
      // click, or every scroll that starts on a dish photo opens the dish.
      justDragged = true;
      setTimeout(() => { justDragged = false; }, 0);
    }
    el = null; moved = false;
  };
  document.addEventListener('pointerup', end);
  document.addEventListener('pointercancel', end);

  // Capture phase, so it runs before the inline onclick handlers on the cards.
  document.addEventListener('click', e => {
    if (!justDragged) return;
    e.stopPropagation();
    e.preventDefault();
  }, true);
}

window.openStaff = openStaff; window.closeStaff = closeStaff; window.staffUnlock = staffUnlock;
window.staffSettings = staffSettings; window.resumeKiosk = resumeKiosk; window.upgradeApp = upgradeApp;
window.openAdminPortal = openAdminPortal; window.exitToDevice = exitToDevice; window.openSuperAdmin = openSuperAdmin;

// ── Load menu ──
async function loadMenu() {
  const r = await fetch(`${CFG.url}/public/menu/${CFG.rid}`, { cache: 'no-store' });
  if (!r.ok) throw new Error('menu ' + r.status);
  const d = await r.json();
  if (!d.ok) throw new Error(d.error || 'menu');
  // Group items by category, preserving server order.
  const cats = [];
  const byCat = {};
  (d.items || []).forEach(it => {
    const c = it.category || 'Menu';
    if (!byCat[c]) { byCat[c] = []; cats.push(c); }
    byCat[c].push(it);
  });
  MENU = { restaurant: d.restaurant || { name: 'Restaurant' }, open: d.open, closedReason: d.closedReason, byCat, cats };
  return MENU;
}

// ── Attract ──
function initial(s) { const c = (String(s || '').trim()[0] || '🍽️'); return c === '🍽️' ? c : c.toUpperCase(); }
// Restaurant logo (img/logo-180.png on the image host) with the letter as a fallback.
function brandLogo(nm) {
  return CFG.imgBase
    ? `${initial(nm)}<img class="brand-img" src="${esc(CFG.imgBase)}logo-180.png" alt="" onerror="this.remove()">`
    : initial(nm);
}
// The backend's closedReason can be a machine code; show customers friendly wording.
function closedText() {
  const map = { outside_hours: 'Outside opening hours', closed: 'Currently closed',
    holiday: 'Closed for a holiday', paused: 'Temporarily not taking orders' };
  const r = MENU.closedReason || '';
  return map[r] || (r ? r.replace(/_/g, ' ') : 'Currently closed');
}
function renderAttract() {
  const nm = MENU.restaurant.name || 'Restaurant';
  $('a-name').textContent = nm;
  $('a-sub').textContent = MENU.restaurant.location || '';
  $('a-logo').innerHTML = brandLogo(nm);
  const closed = $('a-closed');
  const btn = document.querySelector('.start-btn');
  // Closed: customers can still browse the menu, but ordering is blocked (the restaurant is
  // closed — no orders reach an unattended kitchen). Checkout is disabled downstream.
  if (MENU.open === false) {
    if (closed) { closed.hidden = false; closed.textContent = '⏳ ' + closedText(); }
    if (btn) btn.textContent = 'Browse menu';
  } else {
    if (closed) closed.hidden = true;
    if (btn) btn.textContent = 'Tap to order';
  }
}

function startOrder() {
  cart = [];
  show('ordertype');
}
function chooseType(t) { orderType = t; renderMenu(); show('menu'); }

// ── Menu render ──
const ALL = 'All';
// Category icon = the first item in that category that has a photo (falls back to an emoji).
function catIcon(cat) {
  const it = (MENU.byCat[cat] || []).find(x => imgBase(x.name));
  return it ? imgTag(it.name) : "🍽️";
}
function renderMenu() {
  const nm = MENU.restaurant.name || 'Menu';
  $('k-logo').innerHTML = brandLogo(nm);
  $('m-mode').textContent = orderType === 'dinein' ? '🍽️ Dine-in' : '🥡 Pickup';
  const mc = $('menu-closed');
  if (mc) {
    if (MENU.open === false) { mc.hidden = false; mc.textContent = '⏳ ' + closedText() + ' — you can browse the menu, but ordering isn’t available until we reopen.'; }
    else mc.hidden = true;
  }
  const tabs = [ALL, ...MENU.cats];
  activeCat = activeCat && tabs.includes(activeCat) ? activeCat : ALL;
  $('cat-title').textContent = activeCat === ALL ? 'Full menu' : activeCat;
  $('knav').innerHTML = tabs.map(c => {
    const ic = c === ALL ? '🍴' : catIcon(c);
    return `<button class="kcat ${c === activeCat ? 'on' : ''}" onclick="selectCat('${esc(c).replace(/'/g, "\\'")}')">
      <span class="kcat-ic">${ic}</span><span class="kcat-nm">${esc(c)}</span></button>`;
  }).join('');
  renderItems();
  renderCartBar();
}
function selectCat(c) { activeCat = c; renderMenu(); $('items').scrollTop = 0; }

// Photo card, Toast-style: image, name, price. Tapping opens the options sheet.
function itemCard(cat, it, i) {
  const out = it.available === false;
  const label = titleCase(it.name) + (it.size ? ` (${it.size})` : '');
  const img = `<div class="pcard-img"><span class="ph">🍽️</span>${imgTag(it.name)}${
    out ? '<span class="pcard-out-tag">Sold out</span>' : ''}</div>`;
  return `<button class="pcard ${out ? 'out' : ''}" ${out ? 'disabled' : ''}
      onclick="openItem('${esc(cat).replace(/'/g, "\\'")}',${i})">
    ${img}
    <div class="pcard-body">
      <div class="pcard-nm">${esc(label)}</div>
      <div class="pcard-foot">
        <span class="pcard-price">${money(it.price)}</span>
        <span class="pcard-add" aria-hidden="true">+</span>
      </div>
    </div>
  </button>`;
}

function renderItems() {
  const box = $('items');
  if (activeCat === ALL) {
    box.innerHTML = MENU.cats.map(cat => {
      const list = MENU.byCat[cat] || [];
      const cards = list.map((it, i) => itemCard(cat, it, i)).join('');
      return `<section class="cat-section"><h3 class="cat-h">${esc(cat)}</h3><div class="pgrid">${cards}</div></section>`;
    }).join('');
  } else {
    const items = MENU.byCat[activeCat] || [];
    box.innerHTML = items.length
      ? `<div class="pgrid">${items.map((it, i) => itemCard(activeCat, it, i)).join('')}</div>`
      : `<div style="color:var(--muted);padding:40px">No items in ${esc(activeCat)}.</div>`;
  }
}

// ── Item customize sheet ──
let draft = null;
// macOS has no on-screen keyboard that appears when a field is focused — the Accessibility
// Keyboard must be switched on by hand and then floats permanently. A native Mac app would not
// change that, so the kiosk carries its own. It also means the Android build behaves identically
// rather than depending on whichever IME that tablet ships.
const KEY_ROWS = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
const NUM_ROWS = ['123', '456', '789', '0'];
let keyTarget = null;

function openKeys(targetId, mode) {
  keyTarget = targetId || 'd-note';
  const inp = $(keyTarget);
  const rows = mode === 'num' ? NUM_ROWS : KEY_ROWS;
  const el = $('keys');
  el.innerHTML = `
    <div class="keys-in ${mode === 'num' ? 'num' : ''}">
      <div class="keys-preview" id="keys-preview">${esc(inp.dataset.typed || '')}</div>
      ${rows.map(r => `<div class="keys-row">${
        [...r].map(k => `<button class="key" onclick="typeKey('${k}')">${k}</button>`).join('')
      }</div>`).join('')}
      <div class="keys-row">
        ${mode === 'num' ? '' : `<button class="key wide" onclick="typeKey(' ')">space</button>`}
        <button class="key" onclick="typeKey('\b')">⌫</button>
        <button class="key go" onclick="closeKeys()">Done</button>
      </div>
    </div>`;
  el.hidden = false;
}
function typeKey(k) {
  const inp = $(keyTarget);
  const max = Number(inp.getAttribute('maxlength')) || 120;
  let v = inp.dataset.typed || '';
  v = k === '\b' ? v.slice(0, -1) : (v + k).slice(0, max);
  inp.dataset.typed = v;
  inp.value = v;
  $('keys-preview').textContent = v;
}
function closeKeys() {
  $('keys').hidden = true;
  const inp = $(keyTarget);
  if (inp) inp.value = inp.dataset.typed || '';
  if (keyTarget === 'd-note') draft.note = (inp.dataset.typed || '').trim();
}
window.openKeys = openKeys;
window.typeKey = typeKey; window.closeKeys = closeKeys;

function openItem(cat, idx) {
  const it = MENU.byCat[cat][idx];
  draft = { name: it.name, size: it.size || '', unit: Number(it.price), qty: 1, spice: null, note: '' };
  const spiceScale = Number(MENU.restaurant.spiceScale) || 0;
  const spiceOpts = spiceScale >= 3 ? ['Mild', 'Medium', 'Hot'] : [];
  const label = titleCase(it.name) + (it.size ? ` (${it.size})` : '');
  const t = imgTag(it.name);
  $('sheet').innerHTML = `
    <div class="sheet-split">
      <div class="sheet-photo">${t || '<div class="ph">🍽️</div>'}</div>
      <div class="sheet-pane">
        <button class="sheet-x" onclick="closeModal()" aria-label="Close">✕</button>
        <h3>${esc(label)}</h3>
        ${it.description ? `<p class="sheet-desc">${esc(it.description)}</p>` : ''}
        <div class="sheet-scroll">
          ${spiceOpts.length ? `<div class="grp-label">Spice level</div>
            <div class="choices" id="d-spice">${spiceOpts.map(sp => `<button class="choice" onclick="pickSpice(this,'${sp}')">${sp}</button>`).join('')}</div>` : ''}
          <div class="grp-label">Special requests (optional)</div>
          <input class="note-in" id="d-note" readonly
                 placeholder="Tap to add a note" maxlength="120" onclick="openKeys('d-note')">
          <div class="grp-label">Quantity</div>
          <div class="qty"><button onclick="bumpQty(-1)">−</button><span class="n" id="d-qty">1</span><button onclick="bumpQty(1)">+</button></div>
        </div>
        <div class="sheet-total">
          <span class="lbl">Total</span>
          <span class="amt" id="d-total">${money(it.price)}</span>
        </div>
        <div class="sheet-f">
          <button class="ghost" onclick="closeModal()">Cancel</button>
          <button class="primary" id="d-add" onclick="addDraft()">Add to order</button>
        </div>
      </div>
    </div>`;
  openModal();
}
function pickSpice(el, s) { draft.spice = draft.spice === s ? null : s;
  el.parentElement.querySelectorAll('.choice').forEach(c => c.classList.toggle('on', c === el && draft.spice === s)); }
function bumpQty(d) { draft.qty = Math.max(1, draft.qty + d); $('d-qty').textContent = draft.qty;
  // The big total is the number the customer is reading, so quantity has to move it.
  $('d-total').textContent = money(draft.unit * draft.qty); }
function addDraft() {
  // What the on-screen keyboard typed, not the input's value — the field is readonly and only
  // mirrors it.
  draft.note = ($('d-note').dataset.typed || '').trim();
  const opts = [];
  if (draft.spice) opts.push(draft.spice);
  if (draft.note) opts.push(draft.note);
  cart.push({ name: draft.name, size: draft.size, unit: draft.unit, qty: draft.qty, opts,
              note: opts.join('; ') });
  closeModal(); renderCartBar();
  toast('Added to order');
}

// ── Cart ──
function cartCount() { return cart.reduce((n, l) => n + l.qty, 0); }
function cartSubtotal() { return cart.reduce((s, l) => s + l.unit * l.qty, 0); }
// Tax preview using the restaurant's rate from the menu payload. Mirrors the server's math
// (server.js computeCartTotals) so the cart matches the receipt exactly.
function cartTaxRate() { return (MENU && MENU.restaurant && Number(MENU.restaurant.taxRate)) || 0; }
function cartTax() { return Math.round(cartSubtotal() * cartTaxRate() * 100) / 100; }
function cartTotal() { return Math.round((cartSubtotal() + cartTax()) * 100) / 100; }
function taxPct() { const p = +(cartTaxRate() * 100).toFixed(2); return p ? p + '%' : ''; }
function renderCartBar() {
  $('orderbar').classList.toggle('show', cartCount() > 0);
  $('ob-total').textContent = money(cartTotal());   // all-in, with tax
}
function openCart() {
  if (!cart.length) return;
  const lines = cart.map((l, i) => `
    <div class="cline">
      <span class="cq">${l.qty}×</span>
      <div class="cbody"><div class="cnm">${esc(titleCase(l.name))}${l.size ? ' (' + esc(l.size) + ')' : ''}</div>
        ${l.opts.length ? `<div class="copt">${esc(l.opts.join(' · '))}</div>` : ''}
        <button class="crm" onclick="removeLine(${i})">Remove</button></div>
      <span class="cp">${money(l.unit * l.qty)}</span>
    </div>`).join('');
  $('sheet').innerHTML = `
    <div class="sheet-h"><h3>Your order</h3><button class="x" onclick="closeModal()">✕</button></div>
    <div class="sheet-b">
      ${lines}
      <div class="tot"><span>Subtotal</span><span>${money(cartSubtotal())}</span></div>
      ${cartTaxRate() > 0
        ? `<div class="tot"><span>Tax (${taxPct()})</span><span>${money(cartTax())}</span></div>`
        : ''}
      <div class="tot tot-grand"><span>Total</span><span>${money(cartTotal())}</span></div>
    </div>
    <div class="sheet-f">
      <button class="ghost" onclick="closeModal()">Add more</button>
      ${MENU.open === false
        ? `<button class="primary block" disabled style="opacity:.55">Closed — ordering unavailable</button>`
        : `<button class="primary block" onclick="openDetails()">Checkout · ${money(cartTotal())}</button>`}
    </div>`;
  openModal();
}
function removeLine(i) { cart.splice(i, 1); renderCartBar(); if (cart.length) openCart(); else closeModal(); }

// ── Details (name / phone / table) ──
function openDetails() {
  $('sheet').innerHTML = `
    <div class="sheet-h"><h3>Almost done</h3><button class="x" onclick="closeModal()">✕</button></div>
    <div class="sheet-b">
      <div class="field"><label>Name for the order</label>
        <input id="o-name" readonly autocomplete="off" maxlength="40"
               placeholder="Tap to type" onclick="openKeys('o-name')"></div>
      <div class="field"><label>Mobile number <span class="opt">optional — for a text when it's ready</span></label>
        <input id="o-phone" readonly autocomplete="off" placeholder="Tap to type" maxlength="10"
               onclick="openKeys('o-phone','num')"></div>
      ${orderType === 'dinein' ? `<div class="field"><label>Table number</label>
        <input id="o-table" readonly autocomplete="off" placeholder="Tap to type" maxlength="6"
               onclick="openKeys('o-table','num')"></div>` : ''}
      <div id="o-err" style="color:#f0908c;min-height:20px;margin-top:12px"></div>
    </div>
    <div class="sheet-f">
      <button class="ghost" onclick="openCart()">‹ Back</button>
      <button class="primary block" id="o-place" onclick="placeOrder()">Place order</button>
    </div>`;
  openModal();
  setTimeout(() => openKeys('o-name'), 200);
}

// ── Pay by phone ────────────────────────────────────────────────────────────
let payPoll = 0, payDeadline = 0;

function showPayment(d, name) {
  const qr = d.checkoutQr
    ? `<div class="pay-qr">${d.checkoutQr}</div>`
    : `<p class="pay-fallback">${esc(d.checkoutUrl)}</p>`;
  $('pay-body').innerHTML = `
    <div class="pay-amt">${money(d.total)}</div>
    <p class="pay-lead">Scan with your phone camera to pay</p>
    ${qr}
    <p class="pay-note">Order #${esc(String(d.orderId).slice(-5))} · ${esc(name)}<br>
      Your food is sent to the kitchen the moment payment goes through.</p>
    <button class="ghost" onclick="cancelPayment()">Cancel</button>`;
  show('pay');

  // Poll rather than wait on the customer to tell us. Stripe's webhook marks the order paid on
  // the server; this only asks whether that has happened yet.
  payDeadline = Date.now() + 10 * 60 * 1000;
  clearInterval(payPoll);
  payPoll = setInterval(async () => {
    if (Date.now() > payDeadline) { cancelPayment(); toast('Payment timed out — please try again.'); return; }
    try {
      const r = await fetch(`${CFG.url}/public/order/${encodeURIComponent(d.orderId)}/status`, { cache: 'no-store' });
      const st = await r.json();
      if (st.ok && st.paid) { clearInterval(payPoll); payPoll = 0; finishOrder(d, name, ''); }
    } catch (_) { /* a dropped poll is not a failure; the next one will answer */ }
  }, 2500);
}

function cancelPayment() {
  clearInterval(payPoll); payPoll = 0;
  // The order exists on the server but is unpaid, so nothing has printed. Back to the cart, where
  // they can try again or fetch someone.
  show('menu'); openCart();
}

function finishOrder(d, name, table) {
  clearInterval(payPoll); payPoll = 0;
  $('d-num').textContent = 'Order #' + (String(d.orderId).slice(-5));
  $('d-sub').textContent = `${name}, your total is ${money(d.total)}. ` +
    (table ? `We’ll bring it to table ${table}.` : `We’ll call your name at the counter.`);
  show('done');
}
window.cancelPayment = cancelPayment;

async function placeOrder() {
  if (MENU.open === false) { toast('We’re closed right now — browsing only until we reopen.'); return; }
  const name = $('o-name').value.trim();
  const phone = $('o-phone').value.replace(/\D/g, '');
  const table = orderType === 'dinein' ? ($('o-table')?.value.trim() || '') : '';
  const err = $('o-err');
  if (!name) { err.textContent = 'Please enter a name.'; return; }
  // Optional at a kiosk: the customer is standing in the restaurant and will wait. A number
  // entered anyway still has to be a real one, or the ready-text goes nowhere.
  if (phone.length && phone.length !== 10) {
    err.textContent = 'That number needs 10 digits, or leave it blank.'; return; }
  if (orderType === 'dinein' && !table) { err.textContent = 'Please enter your table number.'; return; }

  const btn = $('o-place'); btn.disabled = true; btn.textContent = 'Placing…';
  // Per-item note carries the customizations; the order-level note carries the fulfilment type.
  const items = cart.map(l => ({ name: l.name + (l.size ? ` (${l.size})` : ''), qty: l.qty, note: l.note || '' }));
  const orderNote = orderType === 'dinein' ? `Dine-in — Table ${table}` : 'Pickup';
  try {
    const r = await fetch(`${CFG.url}/public/order`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ restaurantId: CFG.rid, items, name, phone, note: orderNote, channel: 'kiosk' }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) {
      const map = { closed: 'Sorry, we just closed.', name_required: 'Please enter a name.',
        phone_invalid: 'That phone number looks wrong.', no_items: 'Your order is empty.',
        rate_limited: 'Too many orders from this device — try again shortly.' };
      err.textContent = map[d.error] || 'Could not place the order. Please try again.';
      btn.disabled = false; btn.textContent = 'Place order'; return;
    }
    closeModal();
    // Paid on the customer's own phone. No card reader touches this machine: the Square Reader
    // cannot talk to a Mac at all, and Stripe's own reader would be more hardware to buy and
    // mount. The phone in their hand is the one device certain to be there.
    if (d.checkoutUrl) { showPayment(d, name); return; }
    finishOrder(d, name, table);
  } catch (_) {
    err.textContent = 'Network problem. Please try again.';
    btn.disabled = false; btn.textContent = 'Place order';
  }
}

function resetToAttract() {
  cart = []; orderType = 'pickup'; activeCat = null;
  loadMenu().then(renderAttract).catch(() => {});
  show('attract');
  checkUpdate(false);        // returning to idle is a good moment to look for updates
  applyPendingIfIdle();      // and to apply one already downloaded, between customers
}

// ── Modal helpers ──
function openModal() { $('modal').classList.add('on'); }
function closeModal() { $('modal').classList.remove('on'); }
$('modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });

// ── Idle reset ────────────────────────────────────────────────────────────────
// A customer who walks away mid-order shouldn't leave their cart (and name/phone) on screen for
// the next person. After IDLE_MS with no touch, return to the attract/home screen and clear it.
const IDLE_MS = 90 * 1000;
let idleTimer = 0;
function resetIdle() { clearTimeout(idleTimer); idleTimer = setTimeout(onIdle, IDLE_MS); }
function onIdle() {
  // An abandoned staff PIN popup (customer triggered it, or staff walked away) shouldn't stay
  // stuck on screen — close it and go home.
  if (!$('staffgate').hidden) { closeStaff(); resetToAttract(); return; }
  const cur = document.querySelector('.screen.on');
  const id = cur && cur.id;
  // Never interrupt: the home screen itself, one-time setup, or the staff home hub.
  if (!id || id === 'attract' || id === 'setup' || id === 'staffhome') return;
  closeModal();
  resetToAttract();
}
function wireIdle() {
  ['pointerdown', 'touchstart', 'keydown', 'wheel'].forEach(ev =>
    document.addEventListener(ev, resetIdle, { passive: true, capture: true }));
  resetIdle();
}

// ── OTA web updates (silent; applied between customers, never mid-order) ──
const WEB_UPDATE_MANIFEST = 'https://raw.githubusercontent.com/jgreenrise/orders-ota-/main/kiosk-app-version.json';
const WEB_UPDATE_INTERVAL_MS = 60 * 60 * 1000;
let lastUpdCheck = 0, pendingUpdate = false;
function wu() {
  return (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()
    && Capacitor.Plugins && Capacitor.Plugins.WebUpdate) || null;
}
async function markHealthy() { const p = wu(); try { if (p) await p.markHealthy(); } catch (_) {} }
async function checkUpdate(force) {
  const p = wu(); if (!p) return;
  const now = Date.now();
  if (!force && now - lastUpdCheck < WEB_UPDATE_INTERVAL_MS) return;
  lastUpdCheck = now;
  try {
    const nativeV = (await p.getInfo())?.nativeVersion || 1;
    const r = await fetch(`${WEB_UPDATE_MANIFEST}?t=${now}`, { cache: 'no-store' });
    if (!r.ok) return;
    const m = await r.json();
    if (m && m.url && m.version > KIOSK_VERSION && (m.minNative || 0) <= nativeV) {
      const staged = await p.applyUpdate({ url: m.url, version: m.version });   // download in background
      if (staged && staged.ok) { pendingUpdate = true; if (m.force) await p.applyNow(); }
    }
  } catch (_) {}
}
// The attract screen is the only truly idle moment — apply a staged update there so a reload
// never interrupts a customer mid-order.
async function applyPendingIfIdle() { if (pendingUpdate) { const p = wu(); try { if (p) await p.applyNow(); } catch (_) {} } }

// ── Boot ──
let staffWired = false;
async function boot() {
  $('kioskver').textContent = 'kiosk v' + KIOSK_VERSION;
  if (!staffWired) { wireStaffGate(); wireDragScroll(); wireIdle(); staffWired = true; }
  // Optional URL provisioning (?rid=&url=&img=): configure the kiosk from its launch URL,
  // persisted to localStorage so later launches need no query string.
  const q = new URLSearchParams(location.search);
  if (q.get('rid')) localStorage.setItem(K_RID, q.get('rid'));
  if (q.get('url')) localStorage.setItem(K_URL, q.get('url'));
  if (q.has('img')) { const v = q.get('img'); if (v) localStorage.setItem(K_IMG, v); else localStorage.removeItem(K_IMG); }
  CFG = getCfg();
  if (!CFG.rid) {
    superAdmin = false; renderSetup();   // first provisioning: Restaurant ID is entered here
    show('setup'); return;
  }
  try {
    await loadMenu();
    renderAttract();
    show('attract');
    markHealthy();
    checkUpdate(true);
    setInterval(() => checkUpdate(false), 15 * 60 * 1000);   // hourly-gated; fires between customers
  } catch (e) {
    superAdmin = false; renderSetup();   // a failed load may be a mistyped ID — renderSetup exposes it
    $('setup-err').textContent = 'Could not load the menu for restaurant ' + CFG.rid + '. Check the ID and connection.';
    show('setup');
  }
}
window.addEventListener('load', boot);
